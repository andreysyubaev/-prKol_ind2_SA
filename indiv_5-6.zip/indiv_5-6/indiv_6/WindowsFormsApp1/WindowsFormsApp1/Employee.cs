﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Employee
    {
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Otc { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public decimal Salary { get; set; }

        public override string ToString()
        {
            return $"{Surname} {Name} {Otc}, {Gender}, {Age} лет, Зарплата: {Salary:C}";
        }
    }
}
