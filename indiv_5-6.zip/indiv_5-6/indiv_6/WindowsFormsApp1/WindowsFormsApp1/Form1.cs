﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string file = "employeesfile.txt";

            Queue<Employee> maleEmployees = new Queue<Employee>();
            Queue<Employee> femaleEmployees = new Queue<Employee>();

            using (StreamReader sr = new StreamReader(file))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');

                    if (parts.Length == 6)
                    {
                        Employee employee = new Employee
                        {
                            Surname = parts[0].Trim(),
                            Name = parts[1].Trim(),
                            Otc = parts[2].Trim(),
                            Gender = parts[3].Trim(),
                            Age = int.Parse(parts[4].Trim()),
                            Salary = decimal.Parse(parts[5].Trim())
                        };

                        if (employee.Gender.Equals("Male", StringComparison.OrdinalIgnoreCase))
                        {
                            maleEmployees.Enqueue(employee);
                        }
                        else if (employee.Gender.Equals("Female", StringComparison.OrdinalIgnoreCase))
                        {
                            femaleEmployees.Enqueue(employee);
                        }
                    }
                }
            }

            malelistBox.Items.Clear();
            femalelistBox.Items.Clear();

            malelistBox.Items.Add("Мужчины сотрудники:\r\n");
            while (maleEmployees.Count > 0)
            {
                malelistBox.Items.Add(maleEmployees.Dequeue().ToString() + "\r\n");
            }

            femalelistBox.Items.Add("Женщины сотрудники:\r\n");
            while (femaleEmployees.Count > 0)
            {
                femalelistBox.Items.Add(femaleEmployees.Dequeue().ToString() + "\r\n");
            }
        }
    }
}
