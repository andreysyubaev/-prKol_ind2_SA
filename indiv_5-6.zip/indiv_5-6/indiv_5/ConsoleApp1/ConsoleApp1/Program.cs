﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string file = "text.txt";

            Queue<string> upperWords = new Queue<string>();
            Queue<string> lowerWords = new Queue<string>();

            StreamReader sr = new StreamReader(file);
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] words = Regex.Split(line, @"\s+");
                    foreach (var word in words)
                    {
                        if (char.IsUpper(word[0]))
                        {
                            upperWords.Enqueue(word);
                        }
                        else if (char.IsLower(word[0]))
                        {
                            lowerWords.Enqueue(word);
                        }
                    }
                }
            }

            Console.WriteLine("Слова, начинающиеся с заглавных букв:");
            while (upperWords.Count > 0)
            {
                Console.WriteLine(upperWords.Dequeue());
            }

            Console.WriteLine("Слова, начинающиеся со строчных букв:");
            while (lowerWords.Count > 0)
            {
                Console.WriteLine(lowerWords.Dequeue());
            }
            Console.Read();
        }
    }
}
